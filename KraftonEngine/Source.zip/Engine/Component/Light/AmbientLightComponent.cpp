#include "AmbientLightComponent.h"
#include "Render/Types/GlobalLightParams.h"
#include "GameFramework/AActor.h"
#include "GameFramework/World.h"

UAmbientLightComponent::UAmbientLightComponent()
{
	Intensity = 0.15f;
}

void UAmbientLightComponent::PushToScene()
{
	UWorld* World = GetWorld();
	if (!World) return;
	FGlobalAmbientLightParams Params;
	Params.Intensity = Intensity;
	Params.LightColor = LightColor;
	Params.bVisible = bVisible;

	World->GetScene().GetEnvironment().AddGlobalAmbientLight(this, Params);
}

void UAmbientLightComponent::DestroyFromScene()
{
	UWorld* World = GetWorldEvenIfPendingKill();
	if (!World) return;

	World->GetScene().GetEnvironment().RemoveGlobalAmbientLight(this);
}

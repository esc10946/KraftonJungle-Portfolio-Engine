#pragma once
#include "Core/Types/CoreTypes.h"
#include "Object/FName.h"
#include "Object/Reflection/ObjectMacros.h"

class UWorld;

UENUM()
enum class EWorldType : uint32
{
    Editor,			// Editor mode — no BeginPlay
    Game,			// Game mode — BeginPlay/Tick active
    PIE,			// Play In Editor
	EditorPreview,	// Editor preview (e.g. material editor)
};

struct FWorldContext
{
    EWorldType WorldType = EWorldType::Editor;
    UWorld* World = nullptr;
    FString ContextName;
    FName ContextHandle;
};

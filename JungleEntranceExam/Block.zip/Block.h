#pragma once
#include "UGameObject.h"
#include "Shape.h"

enum class EBlockType
{
	Normal,
	Hard,
	Immortal
};
enum class EBlockColor
{
	White = 50,
	Orange = 60,
	Cyan = 70,
	Green = 80,
	Red = 90,
	Blue = 100,
	Magenta = 110,
	Yellow = 120,
	Silver = 50
};

static FColor GetColorFromBlockColor(EBlockColor blockColor)
{
	switch (blockColor)
	{
	case EBlockColor::White:    return FColor(0.9f, 0.9f, 0.9f);
	case EBlockColor::Orange:   return FColor(1.0f, 0.55f, 0.0f);
	case EBlockColor::Cyan:     return FColor(0.0f, 0.9f, 0.9f);
	case EBlockColor::Green:    return FColor(0.0f, 0.8f, 0.0f);
	case EBlockColor::Red:      return FColor(0.9f, 0.0f, 0.0f);
	case EBlockColor::Blue:     return FColor(0.15f, 0.3f, 1.0f);
	case EBlockColor::Magenta:  return FColor(0.9f, 0.0f, 0.9f);
	case EBlockColor::Yellow:   return FColor(1.0f, 0.95f, 0.0f);
	default:                    return FColor(1.0f, 1.0f, 1.0f);
	}
}
class URenderer;
class Block : public UGameObject
{
public:
	Block(EBlockType InType, EBlockColor InColor, int Round=1);
	~Block();

	void Init(float cx, float cy, float hw, float hh);

	void Update(float DeltaTime) override;
	void Render(URenderer& Renderer) override {};
	bool CheckBallCollision(const FVector& BallPos, float Radius, FVector& OutNormal) const;// if creating the Ball Class, Make overload function
	int  TakeDamage();

	FColor GetColor() const;
public:
	EBlockType Type;
	EBlockColor Color;
	int MaxHp;
	int CurrHp;
	float CenterX, CenterY;
	float HalfW, HalfH;



};

#include "Block.h"

#include "UGameObject.h"
#include "URenderer.h"
#include <d3d11.h>
#include <cmath>
static int TotalScore=0;
Block::Block(EBlockType InType, EBlockColor InColor, int Round) :Type(InType),CenterX(0),CenterY(0),HalfW(0),HalfH(0), Color(InColor)
{
    switch (Type)
    {
    case EBlockType::Normal:   MaxHp = 1;                break;
    case EBlockType::Hard:     MaxHp = 2 + (Round / 8); break;
    case EBlockType::Immortal: MaxHp = INT_MAX;          break;
    }
    CurrHp = MaxHp;
   // SetTag("Block");
}

Block::~Block()
{
}

void Block::Init(float cx, float cy, float hw, float hh)
{
    CenterX = cx;
    CenterY = cy;
    HalfH = hh;
    HalfW = hw;
}
void Block::Update(float DeltaTime)
{
    // hmm...

}
bool Block::CheckBallCollision(const FVector& BallPos, float Radius, FVector& OutNormal) const
{
    if (!IsActive()) return false;
    const float overlapX = (HalfW + Radius) - fabsf(BallPos.x - CenterX);
    const float overlapY = (HalfH + Radius) - fabsf(BallPos.y - CenterY);

    if (overlapX <= 0.0f||overlapY<=0.0f)
        return false;

    if (overlapX < overlapY)
        OutNormal = FVector(BallPos.x < CenterX ? -1.0f : 1.0f, 0.0f, 0.0f);
    else
        OutNormal = FVector(0.0f, BallPos.y < CenterY ? -1.0f : 1.0f, 0.0f);

    return true;
}// �Ƹ� �����Ҽ������� ���ʿ��� �ݸ��� üũ�� ���ϸ� ���ٿ���

//void Block::Render(URenderer& Renderer)
//{
//    if (!IsActive())
//        return;
//    FColor color;
//    switch (Type)
//    {
//	case EBlockType::Normal:
//        color = GetColorFromBlockColor(Color);
//        break;
//    case EBlockType::Hard:
//        color = FColor(0.53f, 0.60f, 0.67f); 
//        break;
//	case EBlockType::Immortal:
//        color = FColor(1.00f, 0.55f, 0.10f);
//        break;
//    default:
//        color = FColor(1.0f, 1.0f, 1.0f);
//        break;
//            
//    }
//    Renderer.RenderRect(CenterX, CenterY, HalfW, HalfH, color);
//}


int Block::TakeDamage()//��Ÿ�� �ʿ��ҰŰ�����Ȥ�� �ٸ� �浹�� ������ �ʱ�ȭ�Ǵ���
{
    if (!IsActive() || Type == EBlockType::Immortal)
        return 0;
    CurrHp--;

    if (CurrHp == 0)
    {
        SetActive(false);
        const int score = static_cast<int>(Color);
        TotalScore += score;
        return score;
    }
	return 0;
}

FColor Block::GetColor() const
{
	if (!IsActive())
		return FColor(0.0f, 0.0f, 0.0f, 0.0f);
    switch (Type)
    {
    case EBlockType::Normal:
        return GetColorFromBlockColor(Color);
    case EBlockType::Hard:
        return (CurrHp == MaxHp) ? FColor(1.00f, 0.55f, 0.10f)
            : FColor(0.80f, 0.13f, 0.05f);
    case EBlockType::Immortal:
        return FColor(0.53f, 0.60f, 0.67f);
    default:
        return FColor(1.0f, 1.0f, 1.0f);
    }
}